var colors = require('./colors').colors;

export const appEntireArea = {
  margin:'0px',
  maxWidth: 'none',
  backgroundColor: colors.backgroundColorDark,
  height: '100vh',
  width: '100vw',
  padding:'0'
}

export const sidebarArea = {
  padding:'0'
}
