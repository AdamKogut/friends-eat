export const colors={
  sidebarColor:'#777777',
  darkColor:'#333333',
  backgroundColorDark:'#555555',
  backgroundColorLight:'#999999'
}